CREATE TABLE job_info(
   contact_id INT NOT NULL AUTO_INCREMENT,
   contact_name VARCHAR(100) NOT NULL,
   co_name VARCHAR (100),
   contact_type INT NOT NULL,
   contact_email VARCHAR(100) NOT NULL,
   contact_tele INT(10),
   job_desc VARCHAR(1200),
   submission_date DATE,
   PRIMARY KEY ( contact_id )
);
