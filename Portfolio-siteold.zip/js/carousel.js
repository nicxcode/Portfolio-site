var main = $(function(){
  $('#carousel_1').carousel({
    interval : false
  });
});

$(document).ready(main);
