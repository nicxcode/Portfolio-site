<?php
error_reporting(E_ALL);

if (isset($_POST["submit"])) {
  $name = $_POST['c_name'];
  $email = $_POST['c_email'];
  $coName = $_POST['co_name'];
  $human = intval($_POST['human']);
  $jDesc = $_POST['j_desc'];
  $from = 'Web Form Contact';
  $to = 'example@localhost.com';
  $subject = 'Nicxcode Contact';

$body = "From: $name\n E-Mail: $email\n CoName: $coName\n Description\n $jDesc";

if (!$_Post['c_name']) {
    $errName = 'Info missing: Name';
}
if (!$_POST['c_email'] || !filter_var($_POST['c_email'], FILTER_VALIDATE_EMAIL)) {
	   $errEmail = 'Please enter a valid email address';
}
if (!$_Post['co_name']) {
    $errCoName = 'Info missing: Company Name';
}
if (!$_Post['j_desc']) {
    $errjDesc = 'Info missing: Job Description';
}

if (!$errname && !$erremail && !$errcoName && !$errjDesc) {
	if (mail ($to, $subject, $body, $from)) {
		$result='<div class="alert alert-success">Thank You! I will be in touch</div>';
	} else {
		$result='<div class="alert alert-danger">Sorry there was an error sending your message. Please try again later</div>';
	}
}
	}
?>
